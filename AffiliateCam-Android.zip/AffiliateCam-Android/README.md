# Affiliate Cam Android
Project Android siap dibuild lewat GitHub Actions. UI menggunakan desain Affiliate Cam dan menyertakan video demo `demo.mp4` dari file pengguna.

## Build di HP lewat GitHub
1. Buat repository baru di GitHub.
2. Upload semua isi folder ini.
3. Buka Actions → Build Affiliate Cam APK → Run workflow.
4. Setelah selesai, buka hasil workflow → Artifacts → `AffiliateCam-debug-apk`.

Catatan: project ini membuat aplikasi Android dengan preview/video dan UI Affiliate Cam. Tombol “Kamera Virtual” saat ini adalah UI/preview; belum merupakan system-level virtual camera yang dapat otomatis menjadi sumber kamera TikTok. Implementasi virtual camera Android yang sebenarnya membutuhkan mekanisme khusus dan kompatibilitas perangkat/aplikasi.
